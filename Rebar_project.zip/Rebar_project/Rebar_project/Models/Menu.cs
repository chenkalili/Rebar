﻿using Rebar_project.models;

namespace Rebar_project.Models
{
    class Menu
    {
        public static List<ShakeMenu> _shakes = new List<ShakeMenu>();

        Menu(List<ShakeMenu> shakeMenus) 
        {
            _shakes = shakeMenus;
        }
        public void AddShake(ShakeMenu shake)
        {
            _shakes.Add(shake);
        }
    }
}
