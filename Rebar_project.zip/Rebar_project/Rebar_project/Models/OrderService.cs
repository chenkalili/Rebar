﻿using Microsoft.AspNetCore.Components.Forms;
using Rebar_project.DataAccess;

namespace Rebar_project.Models
{
    public class OrderService
    {
        Order Order;
        OrderDB OrderDB;

        public OrderService(List<ShakeOrder> shakesList)
        {

        }
        public bool NewOrder(List<ShakeOrder> shakesList, List<Discount> discounts, string name)
        {
            DateTime start = DateTime.Now;
            DateTime end = DateTime.Now;
            if (shakesList.Count > 9 || name == null)
                return false;
            double totalPrice= TotalPrice(shakesList);
            double totalDiscount = TotalDiscount(discounts);
            List<Guid> ListID = shakesID(shakesList);
            Order = new Order(shakesList,name, totalPrice, totalDiscount);
            OrderDB = new OrderDB(start, end, ListID, totalPrice,name);
            //OrderDataAccess orderData = new OrderDataAccess(_order);
            return true;
        }
        public List<Guid> shakesID(List<ShakeOrder> shakesList)
        {
            List<Guid> id = new List<Guid>();
            shakesList.ForEach(shakes => id.Add(shakes.ShakeID));
            return id;
        }
        public double TotalPrice(List<ShakeOrder> shakesList)
        {
            double totalPrice = 0;
            shakesList.ForEach(shakes => { totalPrice += shakes.Price; });
            return totalPrice;
        }
        public double TotalDiscount(List<Discount> discounts)
        {
            double totalDiscounts = 0;
            discounts.ForEach(discount => { totalDiscounts += discount.Percentage; });
            return totalDiscounts;
        }
    }
}
